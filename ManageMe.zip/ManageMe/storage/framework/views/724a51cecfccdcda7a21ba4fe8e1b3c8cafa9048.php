<?php $__env->startSection('content'); ?>
    <?php if($post): ?>
        <h1><?php echo e($post->merek); ?></h1>
        <small><?php echo e($post->created_at); ?></small>
        <p><?php echo e($post->description); ?></p>
    <?php else: ?>
        <h1>Tidak Ada Data.</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\project2019\resources\views/posts/show.blade.php ENDPATH**/ ?>