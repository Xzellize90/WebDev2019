@extends('layouts.app')
@section('content')
    @if($post)
        <h1>{{$post->name}}</h1>
        <small>{{$post->created_at}}</small>
        <p>{{$post->description}}</p>
    @else
        <h1>Tidak Ada Data.</h1>
    @endif
@endsection