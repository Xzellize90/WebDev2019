<li class="nav-item
        @if($pageid=='posts')
        active
        @endif
        ">
    <a class="nav-link" href="/posts">Blog Posts</a>
</li>